public class FourColorCard extends WildCard {
    public String effect = "4color";

    public FourColorCard() {
        super();
    }
}

public class Plus4Card extends WildCard {
    public String effect = "plus4";

    public Plus4Card() {
        super();
    }
}

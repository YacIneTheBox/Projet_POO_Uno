package Z;
import javax.swing.JButton;

public class ZButton extends JButton {
public ZButton (String text) {
	super(text) ;
}
}
